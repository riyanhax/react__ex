import React from "react";


export default function(props){
        return (
                <div className="col__md ex__col__3 gray fcoljb">
                    options
                </div>
        )
    
}



